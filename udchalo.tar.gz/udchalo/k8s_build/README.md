## Deployment Steps
# 1. Create a namespace for the proxy

kubectl apply -f namespace.yaml

# 2. Deploy gcr secret to authenticate with gcr.io

kubectl -n udchalo create secret docker-registry gcr-json-key \
--docker-server=gcr.io \
--docker-username=_json_key \
--docker-password="$(cat gcr_auth.json)" \
--docker-email=<email>

# 3. Then to make our namespace use the credentials, we need to update service account's property.

kubectl -n udchalo patch serviceaccount default -p '{"imagePullSecrets": [{"name": "gcr-json-key"}]}'

# 4. Create K8s components from .env:

kubectl -n udchalo create secret generic com.dagknows.secret.frontend --from-env-file=../.env

# 5. Secret for public key:

kubectl -n udchalo create secret generic frontend-keys \
    --from-file=public_key.pem=../agent_frontend/src/keys/public_key.pem

# 6. Vault: Create K8s secrets from repository.

# For local.json
kubectl -n udchalo create configmap vault-configs \
    --from-file=../vault/config/

# For Vault certificates
kubectl -n udchalo create secret generic vault-keys \
    --from-file=vault.crt=../vault/config/ssl/vault.crt \
    --from-file=vault.key=../vault/config/ssl/vault.key

# 7. Deploy the proxy

kubectl apply -f vault.yaml -n udchalo
kubectl apply -f agent-frontend.yaml -n udchalo
kubectl apply -f script-exec.yaml -n udchalo
kubectl apply -f cmd-exec.yaml -n udchalo

