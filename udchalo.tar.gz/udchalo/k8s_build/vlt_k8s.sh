#!/bin/sh
CONTAINER_ID=$(kubectl get pods -n udchalo | grep frontend | awk '{print $1}')
CMD="kubectl exec -it ${CONTAINER_ID} -n udchalo -- python src/vlt.py"
eval $CMD
